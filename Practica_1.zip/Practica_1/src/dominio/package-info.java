/**
 * Este paquete contiene las clases sobre el tema del que trata la
 * aplicación, en concreto, todo aquello relacionado con los contactos,
 * como son la clase `Contacto.java` o la clase `Libreta.java`.
 */
package dominio;
